// Integración con WhatsApp Web: usa sus propios módulos internos (window.require) para
// subir el audio, enviar el sticker con stickerAudio y abrir el diálogo nativo de "Reenviar".
(() => {
  const WAAS = (window.WAAS = window.WAAS || {});
  const log = (lvl, ev, data) => WAAS.log(lvl, ev, data);
  const W = (WAAS.wa = {});

  const SOUND_PROPS = [
    "sound_stickers_consumption_enabled",
    "sound_stickers_creation_enabled",
    "sound_stickers_audio_playing_enabled",
    "sound_stickers_channels_send_enabled",
  ];
  const NEEDED = [
    "WAWebChatCollection", "WAWebMsgCollection", "WAWebMediaPrep", "WAWebMediaOpaqueData",
    "WAWebUploadManagerMainThread", "WAWebUploadManager", "WAWebCreateMediaUploadMetrics", "WAWebMmsMediaTypes",
    "WAWebMediaGetUploadOriginForChat", "WAWebSoundStickerGating", "WAWebSoundStickerUtils", "WAWebABProps",
    "WAWebModalManager", "WAWebForwardMessageFlowLoadable", "WAWebStateUtils", "WAWebUserPrefsMeUser",
    "WAWebFindChatAction", "WAWebSendMsgResultAction", "WAWebAck", "WALogger", "react",
  ];

  // ------------------------------------------------------------ acceso a módulos
  function hasLoader() { return typeof window.require === "function" && typeof window.__d === "function"; }

  function ns(name) {
    if (typeof window.importNamespace === "function") {
      try { const m = window.importNamespace(name); if (m) return m; } catch (e) { /* probar require */ }
    }
    return window.require(name);
  }
  function def(name) {
    const m = ns(name);
    return m && m.default !== undefined ? m.default : m;
  }
  async function load(name, timeoutMs = 15000) {
    try { return ns(name); } catch (e) { /* puede ser un módulo diferido */ }
    if (typeof window.requireLazy !== "function") throw new Error(`Módulo ${name} no disponible y no hay requireLazy`);
    await new Promise((resolve, reject) => {
      const t = setTimeout(() => reject(new Error(`Tiempo agotado cargando el módulo ${name}`)), timeoutMs);
      window.requireLazy([name], () => { clearTimeout(t); resolve(); });
    });
    return ns(name);
  }
  W.ns = ns; W.def = def; W.load = load; W.hasLoader = hasLoader;

  function waVersion() {
    try { return (window.Debug && window.Debug.VERSION) || null; } catch (e) { return null; }
  }

  function abValues() {
    const out = {};
    try {
      const AB = ns("WAWebABProps");
      for (const p of SOUND_PROPS) {
        try { out[p] = AB.getABPropConfigValue(p); } catch (e) { out[p] = "error: " + e.message; }
      }
    } catch (e) { out.error = e.message; }
    return out;
  }

  function isNewsletterChat(chat) {
    try {
      if (!chat) return false;
      if (chat.isNewsletter) return true;
      const id = chat.id;
      if (!id) return false;
      if (id.server === "newsletter") return true;
      if (typeof id.isNewsletter === "function" && id.isNewsletter()) return true;
    } catch (e) {}
    return false;
  }

  function getNewsletterCollection() {
    try {
      const m = ns("WAWebNewsletterCollection");
      if (m) return m.NewsletterCollection || m.default || m;
    } catch (e) {}
    try {
      const keys = Object.keys(window.require("__debug").modulesMap || {});
      const nlName = keys.find((k) => /Newsletter.*Collection/i.test(k));
      if (nlName) {
        const m = ns(nlName);
        if (m) return m.NewsletterCollection || m.default || m;
      }
    } catch (e) {}
    return null;
  }

  function resolveNewsletterChat(chat) {
    if (!isNewsletterChat(chat)) return chat;
    try {
      const NC = getNewsletterCollection();
      if (NC && typeof NC.get === "function") {
        const found = NC.get(chat.id) || NC.get(String((chat.id && chat.id._serialized) || chat.id));
        if (found) return found;
      }
    } catch (e) {}
    return chat;
  }

  // ------------------------------------------------------------ diagnóstico
  W.diagnose = async function () {
    const mods = {};
    for (const n of NEEDED) {
      try { const m = ns(n); mods[n] = m ? "ok" : "vacío"; } catch (e) { mods[n] = "falta: " + e.message.slice(0, 120); }
    }
    let caps = null;
    try { caps = await WAAS.capabilities(); } catch (e) { caps = { error: e.message }; }
    let activeChat = null;
    try { const c = W.getActiveChat(); activeChat = c ? describeChat(c) : null; } catch (e) { activeChat = "error: " + e.message; }
    const d = {
      extension: WAAS.VERSION,
      waVersion: waVersion(),
      loader: { require: typeof window.require, importNamespace: typeof window.importNamespace, requireLazy: typeof window.requireLazy },
      modulos: mods,
      abPropsOriginales: W._abOriginal || abValues(),
      abPropsActuales: abValues(),
      navegador: caps,
      chatAbierto: activeChat,
      gatingForzado: !!W._forced,
    };
    log("info", "diagnostico", d);
    return d;
  };

  function describeChat(chat) {
    try {
      const id = chat.id;
      return {
        tipo: isNewsletterChat(chat) ? "canal" : id.isGroup && id.isGroup() ? "grupo" : id.server === "lid" ? "lid" : id.isUser && id.isUser() ? "usuario" : String(id.server),
        id: WAAS.maskIds(String(id._serialized || id)),
        nombre: WAAS.maskIds(String(chat.formattedTitle || chat.name || "")).slice(0, 40),
      };
    } catch (e) { return { error: e.message }; }
  }
  W.describeChat = describeChat;

  // ------------------------------------------------------------ activar stickers con sonido (local)
  W.forceSoundStickers = function () {
    if (W._forced) return true;
    W._abOriginal = abValues();
    let method = null;
    try {
      const AB = ns("WAWebABProps");
      const orig = AB.getABPropConfigValue;
      if (!orig.__waas) {
        const patched = function (name) {
          if (SOUND_PROPS.includes(name) || (typeof name === "string" && name.includes("sound_stickers"))) return true;
          return orig.apply(this, arguments);
        };
        patched.__waas = true;
        AB.getABPropConfigValue = patched;
      }
      method = "WAWebABProps";
    } catch (e) { log("warn", "gating:abprops-fallo", e); }

    let G;
    try { G = ns("WAWebSoundStickerGating"); } catch (e) { log("error", "gating:modulo-falta", e); }
    const ok = () => { try { return G.isSoundStickerCreationEnabled() === true && G.isSoundStickerConsumptionEnabled() === true; } catch (e) { return false; } };
    if (G) {
      try {
        if (!ok()) {
          G.isSoundStickerConsumptionEnabled = () => true;
          G.isSoundStickerCreationEnabled = () => true;
          G.isSoundStickerPlaybackEnabled = () => true;
          method = "WAWebSoundStickerGating";
        }
        if (typeof G.isSoundStickerChannelsSendEnabled === "function") {
          G.isSoundStickerChannelsSendEnabled = () => true;
        }
      } catch (e) { log("warn", "gating:modulo-falta", e); }
    }

    // Allow unencrypted channel stickerAudio (mediaKey === null) to pass completeness check
    try {
      const U = ns("WAWebSoundStickerUtils");
      if (U && typeof U.isCompleteStickerAudio === "function" && !U.isCompleteStickerAudio.__waas) {
        const origComplete = U.isCompleteStickerAudio;
        const patchedComplete = function (t) {
          if (origComplete.apply(this, arguments)) return true;
          if (t && t.mediaKey === null && (t.directPath || t.deprecatedMms3Url) && t.size > 0 && t.filehash && t.mimetype) {
            return true;
          }
          return false;
        };
        patchedComplete.__waas = true;
        U.isCompleteStickerAudio = patchedComplete;
      }
    } catch (e) { log("warn", "gating:utils-patch", e); }

    W._forced = !!G && ok();
    log(W._forced ? "info" : "error", "gating:forzar", { metodo: method, original: W._abOriginal, ahora: abValues(), activo: W._forced });
    return W._forced;
  };

  // ------------------------------------------------------------ registrar logs internos de WA durante una operación
  W.hookWALogger = function () {
    if (W._loggerHooked) return;
    try {
      const L = ns("WALogger");
      const RELEVANT = /sticker|media|upload|sound|forward|prep|send|mms|encrypt|kaleidoscope|newsletter/i;
      for (const lvl of ["LOG", "WARN", "ERROR"]) {
        const orig = L[lvl];
        if (typeof orig !== "function" || orig.__waas) continue;
        const wrapped = function (strings) {
          try {
            if (WAAS.activeRun && strings && strings.raw) {
              const vals = Array.prototype.slice.call(arguments, 1);
              let msg = "";
              for (let i = 0; i < strings.length; i++) msg += strings[i] + (i < vals.length ? String(vals[i]) : "");
              if (lvl !== "LOG" || RELEVANT.test(msg)) log(lvl === "ERROR" ? "error" : lvl === "WARN" ? "warn" : "info", "wa-" + lvl.toLowerCase(), msg);
            }
          } catch (e) { /* nunca romper el logger de WA */ }
          return orig.apply(this, arguments);
        };
        wrapped.__waas = true;
        L[lvl] = wrapped;
      }
      W._loggerHooked = true;
      log("info", "walogger:enganchado", null);
    } catch (e) { log("warn", "walogger:no-enganchado", e); }
  };

  // ------------------------------------------------------------ chats
  W.getActiveChat = function () {
    const active = ns("WAWebChatCollection").ChatCollection.getActive();
    if (active) return resolveNewsletterChat(active);
    try {
      const NC = getNewsletterCollection();
      if (NC && typeof NC.getActive === "function") {
        const nlActive = NC.getActive();
        if (nlActive) return nlActive;
      }
    } catch (e) {}
    return null;
  };

  W.getSelfChat = async function () {
    const Me = ns("WAWebUserPrefsMeUser");
    const CC = ns("WAWebChatCollection").ChatCollection;
    const getters = ["getMaybeMePnUser", "getMeUserOrThrow", "getMaybeMeLidUser"];
    let firstWid = null;
    for (const g of getters) {
      try {
        const wid = Me[g] && Me[g]();
        if (!wid) continue;
        firstWid = firstWid || wid;
        const c = CC.get(wid) || CC.get(String(wid._serialized || wid));
        if (c) { log("info", "chat-propio:encontrado", { via: g, chat: describeChat(c) }); return c; }
      } catch (e) { /* siguiente */ }
    }
    if (!firstWid) throw new Error("No se pudo obtener tu propio número");
    const r = await ns("WAWebFindChatAction").findOrCreateLatestChat(firstWid, "forwardSelectedModals");
    const chat = r && (r.chat || r);
    log("info", "chat-propio:creado", { chat: describeChat(chat) });
    return chat;
  };

  // ------------------------------------------------------------ subida del audio
  function toB64(v) {
    if (v == null) return v;
    if (typeof v === "string") return v;
    const bytes = v instanceof ArrayBuffer ? new Uint8Array(v) : new Uint8Array(v.buffer || v);
    let s = "";
    for (const b of bytes) s += String.fromCharCode(b);
    return btoa(s);
  }
  function b64Len(s) { try { return s ? atob(s).length : -1; } catch (e) { return -1; } }

  const noopQpl = new Proxy({}, { get: () => () => undefined });

  W.uploadAudio = async function (oggBlob, seconds, chat) {
    const targetChat = resolveNewsletterChat(chat);
    const MT = ns("WAWebMmsMediaTypes").MEDIA_TYPES;
    const isChannel = isNewsletterChat(targetChat);
    let uploadOrigin = 1;
    try { uploadOrigin = def("WAWebMediaGetUploadOriginForChat")(targetChat); } catch (e) { log("warn", "subida:origen", e); }

    const bytes = new Uint8Array(await oggBlob.arrayBuffer());
    const filehash = await WAAS._internals.sha256b64(bytes);
    const dur = Math.max(1, Math.round(Number(seconds) || 1));

    let res = null, via = "";

    // WhatsApp Channels (Newsletters) require NEWSLETTER_AUDIO + unencryptedUpload -> /m1/v/t24/...
    if (isChannel) {
      const umMain = (() => { try { return def("WAWebUploadManagerMainThread"); } catch (e) { return null; } })();
      const um = (() => { try { return def("WAWebUploadManager"); } catch (e) { return null; } })();
      const nlAudioType = MT.NEWSLETTER_AUDIO || "newsletter-audio";
      const baseUnenc = {
        hash: filehash,
        token: filehash,
        type: nlAudioType,
        signal: new AbortController().signal,
        uploadOrigin,
        fileOrigin: undefined,
        isViewOnce: false,
        generateThumbnailOnServer: false,
      };

      const attempts = [
        ["MainThread.unencryptedUpload(buf)", () => umMain && typeof umMain.unencryptedUpload === "function" ? umMain.unencryptedUpload({ ...baseUnenc, file: bytes.buffer }) : null],
        ["MainThread.unencryptedUpload(blob)", () => umMain && typeof umMain.unencryptedUpload === "function" ? umMain.unencryptedUpload({ ...baseUnenc, file: oggBlob }) : null],
        ["UploadManager.unencryptedUpload(buf)", () => um && typeof um.unencryptedUpload === "function" ? um.unencryptedUpload({ ...baseUnenc, file: bytes.buffer }) : null],
        ["UploadManager.unencryptedUpload(blob)", () => um && typeof um.unencryptedUpload === "function" ? um.unencryptedUpload({ ...baseUnenc, file: oggBlob }) : null],
      ];
      let lastErr = "";
      for (const [label, fn] of attempts) {
        try {
          const r = await fn();
          if (r && (r.directPath || r.url)) {
            res = r;
            via = label;
            break;
          }
        } catch (e) {
          lastErr = (e && e.message) ? e.message : String(e);
          log("warn", "subida:canal-" + label, e);
        }
      }
      if (!res) {
        throw new Error("Channel unencrypted audio upload failed: " + lastErr);
      }
    } else {
      const params = {
        blob: oggBlob,
        type: MT.AUDIO,
        signal: new AbortController().signal,
        uploadQpl: noopQpl,
        uploadOrigin,
        fileOrigin: undefined,
        userUploadAttemptCount: 0,
        forwardedFromWeb: false,
        isViewOnce: false,
        isHdPhoto: false,
      };
      try {
        const metrics = def("WAWebCreateMediaUploadMetrics")(params);
        res = await def("WAWebUploadManagerMainThread").encryptAndUpload(params, metrics);
        via = "MainThread";
      } catch (e) {
        log("warn", "subida:mainthread-fallo", e);
        res = await def("WAWebUploadManager").encryptAndUpload(params);
        via = "UploadManager";
      }
    }

    const directPath = res.directPath || null;
    const stickerAudio = {
      deprecatedMms3Url: res.url || (directPath ? "https://mmg.whatsapp.net" + directPath : undefined),
      directPath,
      filehash,
      size: bytes.length,
      mimetype: "audio/ogg; codecs=opus",
      duration: dur,
    };

    if (isChannel) {
      stickerAudio.mediaKey = null;
      stickerAudio.mediaKeyTimestamp = res.mediaKeyTimestamp || Math.floor(Date.now() / 1000);
    } else {
      stickerAudio.mediaKey = toB64(res.mediaKey);
      stickerAudio.mediaKeyTimestamp = res.mediaKeyTimestamp;
      stickerAudio.encFilehash = toB64(res.encFilehash);
    }

    let complete = null;
    try { complete = ns("WAWebSoundStickerUtils").isCompleteStickerAudio(stickerAudio); } catch (e) { complete = "error: " + e.message; }
    log(complete === true || (isChannel && stickerAudio.directPath) ? "info" : "error", "subida:audio", {
      via,
      isChannel,
      directPath: stickerAudio.directPath ? stickerAudio.directPath.split("?")[0] : null,
      tieneUrl: !!stickerAudio.deprecatedMms3Url,
      mediaKeyBytes: b64Len(stickerAudio.mediaKey),
      encFilehashBytes: b64Len(stickerAudio.encFilehash),
      filehash, size: stickerAudio.size, duration: dur,
      isCompleteStickerAudio: complete,
    });
    if (complete !== true && !(isChannel && stickerAudio.directPath)) {
      throw new Error("WhatsApp no considera válido el audio subido (isCompleteStickerAudio=" + complete + ")");
    }
    return stickerAudio;
  };

  // ------------------------------------------------------------ envío del sticker
  W.sendSticker = async function (chat, webpBlob, info, stickerAudio) {
    const targetChat = resolveNewsletterChat(chat);
    const Opaque = def("WAWebMediaOpaqueData");
    const MediaPrep = def("WAWebMediaPrep");
    const opaque = await Opaque.createFromData(webpBlob, "image/webp");
    const data = {
      type: "sticker", mediaBlob: opaque, mimetype: "image/webp", size: webpBlob.size,
      fullWidth: info.lado || 512, fullHeight: info.lado || 512, isAnimated: !!info.isAnimated, emojis: ["🔊"],
    };
    const prep = new MediaPrep("sticker", Promise.resolve(data));
    log("info", "envio:preparado", { chat: describeChat(targetChat), webpBytes: webpBlob.size, conAudio: !!stickerAudio });

    let lastWaErr = "";
    let L = null, origErr = null;
    try {
      L = ns("WALogger");
      origErr = L.ERROR;
      if (typeof origErr === "function") {
        L.ERROR = function (strings) {
          try {
            if (strings && strings.raw) {
              const vals = Array.prototype.slice.call(arguments, 1);
              let m = "";
              for (let i = 0; i < strings.length; i++) m += strings[i] + (i < vals.length ? String(vals[i]) : "");
              if (!lastWaErr) lastWaErr = m.slice(0, 120);
            }
          } catch (e) {}
          return origErr.apply(this, arguments);
        };
      }
    } catch (e) {}

    let res;
    try {
      res = await prep.sendToChat({ chat: targetChat, options: stickerAudio ? { stickerAudio } : {} });
    } finally {
      if (L && origErr) L.ERROR = origErr;
    }

    const OK = ns("WAWebSendMsgResultAction").SendMsgResult.OK;
    const msg = res && res.msg;
    const resumen = {
      resultado: res && res.messageSendResult,
      ok: res && res.messageSendResult === OK,
      msgId: msg && msg.id ? WAAS.maskIds(String(msg.id._serialized || msg.id)) : null,
      msgTieneStickerAudio: msg ? !!(msg.stickerAudio || (msg.attributes && msg.attributes.stickerAudio)) : null,
      ack: msg ? msg.ack : null,
    };
    log(resumen.ok ? "info" : "error", "envio:resultado", resumen);
    if (!resumen.ok) {
      const detail = lastWaErr || (stickerAudio && stickerAudio.directPath ? stickerAudio.directPath.slice(0, 18) : "no-dp");
      throw new Error("WhatsApp no pudo enviar el sticker (" + resumen.resultado + " | " + detail + ")");
    }
    return msg;
  };

  W.waitForAck = async function (msg, timeoutMs = 30000) {
    const ACK = ns("WAWebAck").ACK;
    const t0 = Date.now();
    while (Date.now() - t0 < timeoutMs) {
      const a = msg.ack;
      if (a >= ACK.SENT) { log("info", "envio:ack", { ack: a, ms: Date.now() - t0 }); return a; }
      if (a < 0) throw new Error("El mensaje quedó en estado de error (ack " + a + ")");
      await new Promise((r) => setTimeout(r, 300));
    }
    log("warn", "envio:ack-tiempo-agotado", { ack: msg.ack });
    return msg.ack;
  };

  W.openForward = async function (msg) {
    const React = ns("react");
    const MM = ns("WAWebModalManager");
    const FL = await load("WAWebForwardMessageFlowLoadable");
    const SU = ns("WAWebStateUtils");
    let model = msg;
    try {
      const MC = ns("WAWebMsgCollection").MsgCollection;
      model = MC.get(msg.id) || msg;
    } catch (e) { /* usar msg */ }
    const close = MM.closeModalManager || (() => MM.ModalManager.close());
    MM.ModalManager.open(
      React.createElement(FL.ForwardMessageFlowLoadable, {
        msgs: [SU.unproxy(model)],
        onClose: close,
        onForward: (msgs) => log("info", "reenvio:hecho", { mensajes: msgs ? msgs.length : null }),
      }),
      { transition: "modal-flow" }
    );
    log("info", "reenvio:dialogo-abierto", null);
  };

  // Flujo completo: subir audio, enviar al chat de destino y (opcional) abrir Reenviar.
  W.publish = async function ({ webp, ogg, info }, { destino = "propio", abrirReenviar = true, onProgress } = {}) {
    const prog = onProgress || (() => {});
    W.hookWALogger();
    if (!W.forceSoundStickers()) log("warn", "publicar:gating", "No se pudo activar la opción de stickers con sonido; el audio podría descartarse");
    prog("Buscando chat…");
    const chat = destino === "abierto" ? W.getActiveChat() : await W.getSelfChat();
    if (!chat) throw new Error(destino === "abierto" ? "Abre primero un chat" : "No se encontró tu chat propio");
    prog("Subiendo audio…");
    const stickerAudio = await W.uploadAudio(ogg, info.segundosAudio, chat);
    prog("Enviando sticker…");
    const msg = await W.sendSticker(chat, webp, info, stickerAudio);
    if (abrirReenviar) {
      prog("Esperando confirmación del servidor…");
      await W.waitForAck(msg);
      prog("Abriendo Reenviar…");
      await W.openForward(msg);
    }
    return { chat, msg };
  };
})();