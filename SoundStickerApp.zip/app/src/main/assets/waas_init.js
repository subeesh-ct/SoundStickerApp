(() => {
  const WAAS = (window.WAAS = window.WAAS || {});
  WAAS.VERSION = "android-1.0";
  WAAS.maskIds = function (s) { return String(s || ""); };
  WAAS.log = function (lvl, ev, data) {
    try {
      if (window.AndroidBridge && window.AndroidBridge.onLog) {
        let txt = "";
        if (data !== undefined && data !== null) {
          txt = typeof data === "string" ? data : JSON.stringify(data).slice(0, 300);
        }
        window.AndroidBridge.onLog(String(lvl), String(ev), txt);
      }
    } catch (e) {}
  };
})();
