(() => {
  if (window.WAAS_ANDROID && window.WAAS_ANDROID._installed) return;

  const buffers = { visual: [], audio: [] };

  function b64ChunksToFile(chunks, name, mime) {
    const fullB64 = chunks.join("");
    const bin = atob(fullB64);
    const bytes = new Uint8Array(bin.length);
    for (let i = 0; i < bin.length; i++) bytes[i] = bin.charCodeAt(i);
    return new File([bytes], name || "media.bin", { type: mime || "application/octet-stream" });
  }

  async function findTargetChat(phoneDigits, chatName) {
    const W = window.WAAS.wa;
    if (phoneDigits === "__SELF__" || (!phoneDigits && !chatName)) {
      return await W.getSelfChat();
    }

    const CC = W.ns("WAWebChatCollection").ChatCollection;
    const models = typeof CC.getModelsArray === "function" ? CC.getModelsArray() : Array.from(CC.models || []);

    // 1. Match by phone number first (most accurate)
    if (phoneDigits) {
      const clean = String(phoneDigits).replace(/\D/g, "");
      const last10 = clean.length >= 10 ? clean.slice(-10) : clean;
      if (clean.length >= 7) {
        const byPhone = models.find((c) => {
          try {
            if (c.id && typeof c.id.isGroup === "function" && c.id.isGroup()) return false;
            const u = String((c.id && c.id.user) || "");
            return u && (u === clean || (last10.length >= 8 && u.endsWith(last10)));
          } catch (e) {
            return false;
          }
        });
        if (byPhone) return byPhone;

        // Try opening/creating chat by WidFactory
        try {
          const widStr = clean.length === 10 ? "91" + clean + "@c.us" : clean + "@c.us";
          const WF = W.ns("WAWebWidFactory");
          const wid = WF.createWid(widStr);
          const r = await W.ns("WAWebFindChatAction").findOrCreateLatestChat(wid, "forwardSelectedModals");
          const found = r && (r.chat || r);
          if (found) return found;
        } catch (e) {
          window.WAAS.log("warn", "findChat:wid-fail", e && e.message ? e.message : String(e));
        }
      }
    }

    // 2. Match by Chat / Group Name
    if (chatName) {
      const target = String(chatName).trim().toLowerCase();
      if (target) {
        const exact = models.find((c) => {
          try {
            const t = String(c.formattedTitle || c.name || (c.contact && (c.contact.name || c.contact.pushname)) || "").trim().toLowerCase();
            return t === target;
          } catch (e) {
            return false;
          }
        });
        if (exact) return exact;

        const partial = models.find((c) => {
          try {
            const t = String(c.formattedTitle || c.name || (c.contact && (c.contact.name || c.contact.pushname)) || "").trim().toLowerCase();
            return t && (t.includes(target) || target.includes(t));
          } catch (e) {
            return false;
          }
        });
        if (partial) return partial;
      }
    }

    // 3. Fallback to active chat if open
    const active = W.getActiveChat();
    if (active) return active;

    throw new Error("Chat not found: " + (chatName || phoneDigits || "unknown"));
  }

  function reportProgress(msg, pct) {
    try {
      if (window.AndroidBridge && window.AndroidBridge.onProgress) {
        window.AndroidBridge.onProgress(String(msg || ""), Math.max(0, Math.min(100, Math.round(pct || 0))));
      }
    } catch (e) {}
  }

  function reportDone(ok, msg) {
    try {
      if (window.AndroidBridge && window.AndroidBridge.onSendComplete) {
        window.AndroidBridge.onSendComplete(!!ok, String(msg || ""));
      }
    } catch (e) {}
  }

  window.WAAS_ANDROID = {
    _installed: true,

    resetBuffers() {
      buffers.visual = [];
      buffers.audio = [];
    },

    appendChunk(slot, b64) {
      if (!buffers[slot]) buffers[slot] = [];
      buffers[slot].push(b64);
    },

    checkStatus() {
      let loggedIn = false;
      let ready = false;
      try {
        const W = window.WAAS && window.WAAS.wa;
        if (W && W.hasLoader()) {
          ready = true;
          const Me = W.ns("WAWebUserPrefsMeUser");
          const meWid = (Me.getMaybeMePnUser && Me.getMaybeMePnUser()) || (Me.getMaybeMeLidUser && Me.getMaybeMeLidUser());
          const CC = W.ns("WAWebChatCollection").ChatCollection;
          if (meWid || (CC && CC.length > 0)) {
            loggedIn = true;
          }
        }
      } catch (e) {}
      try {
        if (window.AndroidBridge && window.AndroidBridge.onStatus) {
          window.AndroidBridge.onStatus(ready, loggedIn);
        }
      } catch (e) {}
      return loggedIn;
    },

    async sendSoundSticker(configJson) {
      const WAAS = window.WAAS;
      const W = WAAS.wa;
      try {
        const cfg = typeof configJson === "string" ? JSON.parse(configJson) : configJson;
        if (!W || !W.hasLoader()) throw new Error("WhatsApp Web is not connected yet");

        reportProgress("Reading media files...", 5);
        if (!buffers.visual.length) throw new Error("No video or GIF selected");

        const vFile = b64ChunksToFile(buffers.visual, cfg.visualName, cfg.visualMime);
        let aFile = null;
        if (!cfg.useVideoAudio) {
          if (!buffers.audio.length) throw new Error("No audio selected or recorded");
          aFile = b64ChunksToFile(buffers.audio, cfg.audioName, cfg.audioMime);
        }

        // Free raw base64 chunks immediately to save RAM
        buffers.visual = [];
        buffers.audio = [];

        const isGifOrAnim = WAAS.isAnimationFile(vFile);
        const isImg = /^image\//i.test(vFile.type || "") && !isGifOrAnim;
        let visualKind = "video";
        let vDur = 5;

        reportProgress("Analyzing media...", 12);
        if (isGifOrAnim) {
          const info = await WAAS.probeAnimation(vFile);
          if (info.animated) {
            visualKind = "gif";
            vDur = Math.max(0.5, info.duration || 3);
          } else {
            visualKind = "image";
          }
        } else if (isImg) {
          visualKind = "image";
        } else {
          visualKind = "video";
          const vInfo = await WAAS.probeVideo(vFile);
          vDur = Math.max(0.5, vInfo.duration || 5);
        }

        if (cfg.useVideoAudio && visualKind !== "video") {
          throw new Error("GIF/Image has no sound. Please Record Mic or Pick Audio.");
        }

        const audioSourceFile = cfg.useVideoAudio ? vFile : aFile;
        const aInfo = await WAAS.probeAudio(audioSourceFile);
        const rawADur = Math.max(0.3, aInfo.duration || 1);

        let targetVisualDur;
        let targetAudioDur;
        let fitMode = "repetir";

        if (cfg.useVideoAudio) {
          const capped = Math.min(vDur, rawADur, 10);
          targetVisualDur = capped;
          targetAudioDur = capped;
        } else {
          targetAudioDur = Math.min(rawADur, 25);
          targetVisualDur = visualKind === "image" ? targetAudioDur : Math.min(vDur, targetAudioDur);
          fitMode = "repetir";
        }

        reportProgress("Compressing sticker & audio...", 20);
        const converted = await WAAS.convert({
          visual: { kind: visualKind, file: vFile, start: 0, dur: targetVisualDur },
          audio: { file: audioSourceFile, start: 0, dur: targetAudioDur },
          fit: fitMode,
          mode: "ajustar",
          still: visualKind === "image",
          onProgress: (txt, frac) => {
            reportProgress("Compressing (" + Math.round((frac || 0) * 100) + "%)", 20 + (frac || 0) * 55);
          },
        });

        reportProgress("Enabling sound stickers...", 78);
        W.forceSoundStickers();

        reportProgress("Finding target chat...", 82);
        const chat = await findTargetChat(cfg.phone, cfg.chatName);
        const chatLabel = String(chat.formattedTitle || chat.name || (chat.id && chat.id.user) || "Chat");

        reportProgress("Uploading audio...", 87);
        const stickerAudio = await W.uploadAudio(converted.ogg, converted.info.segundosAudio, chat);

        reportProgress("Sending sticker...", 94);
        const msg = await W.sendSticker(chat, converted.webp, converted.info, stickerAudio);

        try {
          await W.waitForAck(msg, 12000);
        } catch (e) {}

        reportProgress("Sent!", 100);
        reportDone(true, "Sent to " + chatLabel);
      } catch (err) {
        buffers.visual = [];
        buffers.audio = [];
        reportDone(false, err && err.message ? err.message : String(err));
      }
    },
  };

  setInterval(() => {
    try { window.WAAS_ANDROID.checkStatus(); } catch (e) {}
  }, 3000);
  window.WAAS_ANDROID.checkStatus();
})();
