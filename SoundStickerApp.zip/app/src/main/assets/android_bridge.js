(() => {
  if (window.WAAS_ANDROID && window.WAAS_ANDROID._installed) return;

  const buffers = { visual: [], audio: [] };

  function b64ChunksToFile(chunks, name, mime) {
    const fullB64 = chunks.join("");
    const bin = atob(fullB64);
    const bytes = new Uint8Array(bin.length);
    for (let i = 0; i < bin.length; i++) bytes[i] = bin.charCodeAt(i);
    return new File([bytes], name || "media.bin", { type: mime || "application/octet-stream" });
  }

  function cleanText(s) {
    return String(s || "")
      .replace(/[\u200E\u200F\u202A-\u202E\u2066-\u2069]/g, "")
      .replace(/\s+/g, " ")
      .trim()
      .toLowerCase();
  }

  function isSelfLabel(name) {
    const t = cleanText(name);
    return t === "you" || t.endsWith("(you)") || t === "நீங்கள்" || t.endsWith("(நீங்கள்)");
  }

  function isSelfChatModel(c) {
    try {
      return !!(c && c.contact && c.contact.isMe);
    } catch (e) {
      return false;
    }
  }

  function getChatTitles(c) {
    const list = [];
    try {
      const candidates = [
        c.formattedTitle,
        c.name,
        c.contact && c.contact.verifiedName,
        c.contact && c.contact.name,
        c.contact && c.contact.pushname,
        c.contact && c.contact.shortName,
        c.contact && c.contact.formattedName,
      ];
      for (const item of candidates) {
        const cleaned = cleanText(item);
        if (cleaned) list.push(cleaned);
      }
    } catch (e) {}
    return list;
  }

  function getChatPhoneUsers(c) {
    const nums = [];
    try {
      if (c.id && typeof c.id.isGroup === "function" && c.id.isGroup()) return nums;
      if (c.id && c.id.user && c.id.server !== "lid") {
        nums.push(String(c.id.user).replace(/\D/g, ""));
      }
      if (c.contact && c.contact.phoneNumber && c.contact.phoneNumber.user) {
        nums.push(String(c.contact.phoneNumber.user).replace(/\D/g, ""));
      }
      if (c.contact && c.contact.id && c.contact.id.user && c.contact.id.server !== "lid") {
        nums.push(String(c.contact.id.user).replace(/\D/g, ""));
      }
    } catch (e) {}
    return nums.filter(Boolean);
  }

  async function resolveSelfChat(W, models) {
    try {
      const selfChat = await W.getSelfChat();
      if (selfChat) return selfChat;
    } catch (e) {}

    try {
      const Me = W.ns("WAWebUserPrefsMeUser");
      const mePn = Me.getMaybeMePnUser && Me.getMaybeMePnUser();
      const meLid = Me.getMaybeMeLidUser && Me.getMaybeMeLidUser();
      const mePnUser = mePn && mePn.user ? String(mePn.user) : "";
      const meLidUser = meLid && meLid.user ? String(meLid.user) : "";

      const fromModels = models.find((c) => {
        try {
          if (c.contact && c.contact.isMe) return true;
          const u = c.id && c.id.user ? String(c.id.user) : "";
          return (mePnUser && u === mePnUser) || (meLidUser && u === meLidUser);
        } catch (e) {
          return false;
        }
      });
      if (fromModels) return fromModels;

      const targetWid = mePn || meLid;
      if (targetWid) {
        const r = await W.ns("WAWebFindChatAction").findOrCreateLatestChat(targetWid, "forwardSelectedModals");
        const found = r && (r.chat || r);
        if (found) return found;
      }
    } catch (e) {
      window.WAAS.log("warn", "findChat:self-fallback-fail", e && e.message ? e.message : String(e));
    }
    throw new Error("Could not find Your Chat (Self). Open a friend's chat or tap Self again.");
  }

  async function findTargetChat(phoneDigits, chatName) {
    const W = window.WAAS.wa;
    const CC = W.ns("WAWebChatCollection").ChatCollection;
    const models = typeof CC.getModelsArray === "function" ? CC.getModelsArray() : Array.from(CC.models || []);

    if (phoneDigits === "__SELF__" || (!phoneDigits && !chatName) || isSelfLabel(chatName)) {
      return await resolveSelfChat(W, models);
    }

    // 1. Match by phone number first (supports normal, foreign, business & LID chats)
    if (phoneDigits) {
      let clean = String(phoneDigits).replace(/\D/g, "");
      if (clean.startsWith("00") && clean.length > 10) {
        clean = clean.slice(2);
      }
      const last10 = clean.length >= 10 ? clean.slice(-10) : clean;
      if (clean.length >= 7) {
        const byPhone = models.find((c) => {
          if (isSelfChatModel(c)) return false;
          const users = getChatPhoneUsers(c);
          return users.some((u) => u === clean || (last10.length >= 8 && u.endsWith(last10)));
        });
        if (byPhone) return byPhone;

        // Try opening/creating chat by WidFactory (exact foreign/full number first, then 91 fallback for 10-digit Indian numbers)
        const widCandidates = clean.length === 10 ? [clean + "@c.us", "91" + clean + "@c.us"] : [clean + "@c.us"];
        for (const widStr of widCandidates) {
          try {
            const WF = W.ns("WAWebWidFactory");
            const wid = WF.createWid(widStr);
            const r = await W.ns("WAWebFindChatAction").findOrCreateLatestChat(wid, "forwardSelectedModals");
            const found = r && (r.chat || r);
            if (found && !isSelfChatModel(found)) return found;
          } catch (e) {
            window.WAAS.log("warn", "findChat:wid-fail", e && e.message ? e.message : String(e));
          }
        }
      }
    }

    // 2. Match by Chat / Business / Group Name (exclude Self chat so short names like "Me" never hit Self)
    if (chatName) {
      const target = cleanText(chatName);
      if (target) {
        const exact = models.find((c) => !isSelfChatModel(c) && getChatTitles(c).some((t) => t === target));
        if (exact) return exact;

        // Only allow partial match for longer names (>= 4 chars) to avoid false matches like "Me" -> "Message yourself"
        if (target.length >= 4) {
          const partial = models.find(
            (c) => !isSelfChatModel(c) && getChatTitles(c).some((t) => t.includes(target) || target.includes(t))
          );
          if (partial) return partial;
        }
      }
    }

    // Do NOT silently fall back to active chat when a specific target was requested
    throw new Error("Chat not found: " + (chatName || phoneDigits || "unknown"));
  }

  function reportProgress(msg, pct) {
    try {
      if (window.AndroidBridge && window.AndroidBridge.onProgress) {
        window.AndroidBridge.onProgress(String(msg || ""), Math.max(0, Math.min(100, Math.round(pct || 0))));
      }
    } catch (e) {}
  }

  function reportDone(ok, msg) {
    try {
      if (window.AndroidBridge && window.AndroidBridge.onSendComplete) {
        window.AndroidBridge.onSendComplete(!!ok, String(msg || ""));
      }
    } catch (e) {}
  }

  window.WAAS_ANDROID = {
    _installed: true,

    resetBuffers() {
      buffers.visual = [];
      buffers.audio = [];
    },

    appendChunk(slot, b64) {
      if (!buffers[slot]) buffers[slot] = [];
      buffers[slot].push(b64);
    },

    checkStatus() {
      let loggedIn = false;
      let ready = false;
      try {
        const W = window.WAAS && window.WAAS.wa;
        if (W && W.hasLoader()) {
          ready = true;
          const Me = W.ns("WAWebUserPrefsMeUser");
          const meWid = (Me.getMaybeMePnUser && Me.getMaybeMePnUser()) || (Me.getMaybeMeLidUser && Me.getMaybeMeLidUser());
          const CC = W.ns("WAWebChatCollection").ChatCollection;
          if (meWid || (CC && CC.length > 0)) {
            loggedIn = true;
          }
        }
      } catch (e) {}
      try {
        if (window.AndroidBridge && window.AndroidBridge.onStatus) {
          window.AndroidBridge.onStatus(ready, loggedIn);
        }
      } catch (e) {}
      return loggedIn;
    },

    async sendSoundSticker(configJson) {
      const WAAS = window.WAAS;
      const W = WAAS.wa;
      try {
        const cfg = typeof configJson === "string" ? JSON.parse(configJson) : configJson;
        if (!W || !W.hasLoader()) throw new Error("WhatsApp Web is not connected yet");

        reportProgress("Reading media files...", 5);
        if (!buffers.visual.length) throw new Error("No video or GIF selected");

        const vFile = b64ChunksToFile(buffers.visual, cfg.visualName, cfg.visualMime);
        let aFile = null;
        if (!cfg.useVideoAudio) {
          if (!buffers.audio.length) throw new Error("No audio selected or recorded");
          aFile = b64ChunksToFile(buffers.audio, cfg.audioName, cfg.audioMime);
        }

        buffers.visual = [];
        buffers.audio = [];

        const isGifOrAnim = WAAS.isAnimationFile(vFile);
        const isImg = /^image\//i.test(vFile.type || "") && !isGifOrAnim;
        let visualKind = "video";
        let vDur = 5;

        reportProgress("Analyzing media...", 12);
        if (isGifOrAnim) {
          const info = await WAAS.probeAnimation(vFile);
          if (info.animated) {
            visualKind = "gif";
            vDur = Math.max(0.5, info.duration || 3);
          } else {
            visualKind = "image";
          }
        } else if (isImg) {
          visualKind = "image";
        } else {
          visualKind = "video";
          const vInfo = await WAAS.probeVideo(vFile);
          vDur = Math.max(0.5, vInfo.duration || 5);
        }

        if (cfg.useVideoAudio && visualKind !== "video") {
          throw new Error("GIF/Image has no sound. Please Record Mic or Pick Audio.");
        }

        const audioSourceFile = cfg.useVideoAudio ? vFile : aFile;
        const aInfo = await WAAS.probeAudio(audioSourceFile);
        const rawADur = Math.max(0.3, aInfo.duration || 1);

        let targetVisualDur;
        let targetAudioDur;
        let fitMode = "repetir";

        if (cfg.useVideoAudio) {
          const capped = Math.min(vDur, rawADur, 10);
          targetVisualDur = capped;
          targetAudioDur = capped;
        } else {
          targetAudioDur = Math.min(rawADur, 25);
          targetVisualDur = visualKind === "image" ? targetAudioDur : Math.min(vDur, targetAudioDur);
          fitMode = "repetir";
        }

        reportProgress("Compressing sticker & audio...", 20);
        const converted = await WAAS.convert({
          visual: { kind: visualKind, file: vFile, start: 0, dur: targetVisualDur },
          audio: { file: audioSourceFile, start: 0, dur: targetAudioDur },
          fit: fitMode,
          mode: "ajustar",
          still: visualKind === "image",
          onProgress: (txt, frac) => {
            reportProgress("Compressing (" + Math.round((frac || 0) * 100) + "%)", 20 + (frac || 0) * 55);
          },
        });

        reportProgress("Enabling sound stickers...", 78);
        W.forceSoundStickers();

        reportProgress("Finding target chat...", 82);
        const chat = await findTargetChat(cfg.phone, cfg.chatName);
        const chatLabel = String(
          chat.formattedTitle ||
            chat.name ||
            (chat.contact && (chat.contact.verifiedName || chat.contact.name)) ||
            (chat.id && chat.id.user) ||
            "Chat"
        );

        reportProgress("Uploading audio...", 87);
        const stickerAudio = await W.uploadAudio(converted.ogg, converted.info.segundosAudio, chat);

        reportProgress("Sending sticker...", 94);
        const msg = await W.sendSticker(chat, converted.webp, converted.info, stickerAudio);

        try {
          await W.waitForAck(msg, 12000);
        } catch (e) {}

        reportProgress("Sent!", 100);
        reportDone(true, "Sent to " + chatLabel);
      } catch (err) {
        buffers.visual = [];
        buffers.audio = [];
        reportDone(false, err && err.message ? err.message : String(err));
      }
    },
  };

  setInterval(() => {
    try { window.WAAS_ANDROID.checkStatus(); } catch (e) {}
  }, 3000);
  window.WAAS_ANDROID.checkStatus();
})();
