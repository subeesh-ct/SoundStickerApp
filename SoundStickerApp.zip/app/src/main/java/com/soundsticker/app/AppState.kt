package com.soundsticker.app

import android.os.Handler
import android.os.Looper
import java.util.concurrent.CopyOnWriteArraySet

object AppState {
    private val mainHandler = Handler(Looper.getMainLooper())
    private val listeners = CopyOnWriteArraySet<() -> Unit>()

    @Volatile var isServiceRunning: Boolean = false
    @Volatile var isWaEngineReady: Boolean = false
    @Volatile var isWhatsAppConnected: Boolean = false
    @Volatile var isInWhatsApp: Boolean = false
    @Volatile var onlyShowInWhatsApp: Boolean = false
    @Volatile var detectedChatName: String = ""
    @Volatile var detectedPhoneNumber: String = ""
    @Volatile var isQrScreenOpen: Boolean = false

    fun addListener(listener: () -> Unit) {
        listeners.add(listener)
    }

    fun removeListener(listener: () -> Unit) {
        listeners.remove(listener)
    }

    fun notifyChange() {
        mainHandler.post {
            listeners.forEach { it.invoke() }
        }
    }
}
