package com.soundsticker.app

import android.annotation.SuppressLint
import android.content.Context
import android.net.Uri
import android.os.Handler
import android.os.Looper
import android.provider.OpenableColumns
import android.util.Base64
import android.view.ViewGroup
import android.webkit.CookieManager
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import org.json.JSONObject
import java.io.File
import java.io.FileInputStream
import java.io.InputStream
import java.util.concurrent.Executors

object WaWebEngine {
    interface SendCallback {
        fun onProgress(message: String, percent: Int)
        fun onComplete(success: Boolean, message: String)
    }

    private val mainHandler = Handler(Looper.getMainLooper())
    private val ioExecutor = Executors.newSingleThreadExecutor()

    @SuppressLint("StaticFieldLeak")
    private var webView: WebView? = null
    private var appContext: Context? = null
    private var hasLoadedOnce = false
    private var activeCallback: SendCallback? = null

    private const val DESKTOP_UA =
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36"

    @SuppressLint("SetJavaScriptEnabled")
    fun init(context: Context) {
        if (webView != null) return
        val ctx = context.applicationContext
        appContext = ctx

        val wv = WebView(ctx).apply {
            layoutParams = ViewGroup.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT
            )
            settings.apply {
                javaScriptEnabled = true
                domStorageEnabled = true
                databaseEnabled = true
                allowFileAccess = true
                allowContentAccess = true
                mediaPlaybackRequiresUserGesture = false
                mixedContentMode = WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE
                userAgentString = DESKTOP_UA
                // Pinch-to-Zoom for QR Code scanning
                setSupportZoom(true)
                builtInZoomControls = true
                displayZoomControls = false
                loadWithOverviewMode = true
                useWideViewPort = true
            }
            CookieManager.getInstance().apply {
                setAcceptCookie(true)
                setAcceptThirdPartyCookies(this@apply, true)
            }
            addJavascriptInterface(JsBridge(), "AndroidBridge")
            webChromeClient = WebChromeClient()
            webViewClient = object : WebViewClient() {
                override fun onPageFinished(view: WebView?, url: String?) {
                    super.onPageFinished(view, url)
                    if (url != null && url.contains("web.whatsapp.com")) {
                        injectScripts()
                    }
                }
            }
        }
        webView = wv
    }

    fun attachTo(container: ViewGroup) {
        val wv = webView ?: return
        val currentParent = wv.parent as? ViewGroup
        if (currentParent === container) return
        currentParent?.removeView(wv)
        container.removeAllViews()
        container.addView(
            wv,
            ViewGroup.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT
            )
        )
    }

    fun detachIfAttachedTo(container: ViewGroup) {
        val wv = webView ?: return
        if (wv.parent === container) {
            container.removeView(wv)
        }
    }

    fun ensureLoaded() {
        val wv = webView ?: return
        if (!hasLoadedOnce) {
            hasLoadedOnce = true
            wv.loadUrl("https://web.whatsapp.com/")
        }
    }

    fun manualReload() {
        val wv = webView ?: return
        hasLoadedOnce = true
        wv.loadUrl("https://web.whatsapp.com/")
    }

    private fun injectScripts() {
        val ctx = appContext ?: return
        val wv = webView ?: return
        val assetFiles = listOf("waas_init.js", "convert.js", "wa.js", "android_bridge.js")
        ioExecutor.execute {
            val combined = StringBuilder()
            for (name in assetFiles) {
                try {
                    ctx.assets.open(name).bufferedReader().use {
                        combined.append(it.readText()).append("\n;\n")
                    }
                } catch (_: Exception) {
                }
            }
            val script = combined.toString()
            mainHandler.post {
                wv.evaluateJavascript(script, null)
            }
        }
    }

    fun sendSoundSticker(
        context: Context,
        visualUri: Uri,
        audioUri: Uri?,
        recordedAudioFile: File?,
        useVideoAudio: Boolean,
        phone: String,
        chatName: String,
        callback: SendCallback
    ) {
        val wv = webView
        if (wv == null) {
            callback.onComplete(false, "WhatsApp WebView not initialized")
            return
        }
        activeCallback = callback
        callback.onProgress("Loading files into engine...", 2)

        ioExecutor.execute {
            try {
                mainHandler.post {
                    wv.evaluateJavascript("window.WAAS_ANDROID && window.WAAS_ANDROID.resetBuffers();", null)
                }

                val vName = queryFileName(context, visualUri) ?: "sticker.mp4"
                val vMime = context.contentResolver.getType(visualUri) ?: guessMime(vName)
                context.contentResolver.openInputStream(visualUri)?.use { stream ->
                    streamChunksToWebView(wv, "visual", stream)
                } ?: throw IllegalStateException("Cannot open selected video/GIF")

                var aName = ""
                var aMime = ""
                if (!useVideoAudio) {
                    if (recordedAudioFile != null && recordedAudioFile.exists()) {
                        aName = recordedAudioFile.name
                        aMime = "audio/mp4"
                        FileInputStream(recordedAudioFile).use { stream ->
                            streamChunksToWebView(wv, "audio", stream)
                        }
                    } else if (audioUri != null) {
                        aName = queryFileName(context, audioUri) ?: "audio.mp3"
                        aMime = context.contentResolver.getType(audioUri) ?: guessMime(aName)
                        context.contentResolver.openInputStream(audioUri)?.use { stream ->
                            streamChunksToWebView(wv, "audio", stream)
                        } ?: throw IllegalStateException("Cannot open selected audio")
                    } else {
                        throw IllegalStateException("Please record mic or pick an audio file")
                    }
                }

                val cfg = JSONObject().apply {
                    put("phone", phone)
                    put("chatName", chatName)
                    put("visualName", vName)
                    put("visualMime", vMime)
                    put("audioName", aName)
                    put("audioMime", aMime)
                    put("useVideoAudio", useVideoAudio)
                }
                val cfgLiteral = JSONObject.quote(cfg.toString())
                mainHandler.post {
                    wv.evaluateJavascript(
                        "if(window.WAAS_ANDROID){window.WAAS_ANDROID.sendSoundSticker($cfgLiteral);}else if(window.AndroidBridge){window.AndroidBridge.onSendComplete(false,'Engine still loading, retry in 3s');}",
                        null
                    )
                }
            } catch (e: Exception) {
                mainHandler.post {
                    activeCallback?.onComplete(false, e.message ?: "Failed reading files")
                    activeCallback = null
                }
            }
        }
    }

    private fun streamChunksToWebView(wv: WebView, slot: String, stream: InputStream) {
        // 192KB raw bytes (divisible by 3 so Base64 chunks never have mid-stream '=' padding)
        val buf = ByteArray(192 * 1024)
        while (true) {
            val read = readFully(stream, buf)
            if (read <= 0) break
            val b64 = Base64.encodeToString(buf, 0, read, Base64.NO_WRAP)
            val js = "window.WAAS_ANDROID && window.WAAS_ANDROID.appendChunk('$slot','$b64');"
            mainHandler.post {
                wv.evaluateJavascript(js, null)
            }
        }
    }

    private fun readFully(stream: InputStream, buf: ByteArray): Int {
        var total = 0
        while (total < buf.size) {
            val n = stream.read(buf, total, buf.size - total)
            if (n < 0) break
            total += n
        }
        return total
    }

    private fun queryFileName(context: Context, uri: Uri): String? {
        return try {
            context.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c ->
                if (c.moveToFirst()) c.getString(0) else null
            }
        } catch (_: Exception) {
            null
        }
    }

    private fun guessMime(name: String): String {
        val lower = name.lowercase()
        return when {
            lower.endsWith(".gif") -> "image/gif"
            lower.endsWith(".webp") -> "image/webp"
            lower.endsWith(".png") -> "image/png"
            lower.endsWith(".jpg") || lower.endsWith(".jpeg") -> "image/jpeg"
            lower.endsWith(".mp4") -> "video/mp4"
            lower.endsWith(".webm") -> "video/webm"
            lower.endsWith(".mp3") -> "audio/mpeg"
            lower.endsWith(".m4a") -> "audio/mp4"
            lower.endsWith(".ogg") -> "audio/ogg"
            lower.endsWith(".wav") -> "audio/wav"
            else -> "application/octet-stream"
        }
    }

    private class JsBridge {
        @JavascriptInterface
        fun onStatus(ready: Boolean, loggedIn: Boolean) {
            val changed = AppState.isWaEngineReady != ready || AppState.isWhatsAppConnected != loggedIn
            AppState.isWaEngineReady = ready
            AppState.isWhatsAppConnected = loggedIn
            if (changed) AppState.notifyChange()
        }

        @JavascriptInterface
        fun onProgress(message: String, percent: Int) {
            mainHandler.post {
                activeCallback?.onProgress(message, percent)
            }
        }

        @JavascriptInterface
        fun onSendComplete(success: Boolean, message: String) {
            mainHandler.post {
                activeCallback?.onComplete(success, message)
                activeCallback = null
            }
        }

        @JavascriptInterface
        fun onLog(level: String, event: String, data: String) {
            android.util.Log.d("WAAS_JS", "[$level] $event $data")
        }
    }
}
