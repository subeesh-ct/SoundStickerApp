package com.soundsticker.app

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity

class MediaPickerActivity : AppCompatActivity() {

    companion object {
        private const val EXTRA_KIND = "kind"
        const val KIND_VISUAL = "visual"
        const val KIND_AUDIO = "audio"

        private var onPicked: ((Uri?) -> Unit)? = null

        fun launch(context: Context, kind: String, callback: (Uri?) -> Unit) {
            onPicked = callback
            val intent = Intent(context, MediaPickerActivity::class.java).apply {
                putExtra(EXTRA_KIND, kind)
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_NO_ANIMATION)
            }
            context.startActivity(intent)
        }
    }

    private val openDocLauncher = registerForActivityResult(
        ActivityResultContracts.OpenDocument()
    ) { uri: Uri? ->
        if (uri != null) {
            try {
                contentResolver.takePersistableUriPermission(
                    uri,
                    Intent.FLAG_GRANT_READ_URI_PERMISSION
                )
            } catch (_: Exception) {
            }
        }
        val cb = onPicked
        onPicked = null
        cb?.invoke(uri)
        finish()
        overridePendingTransition(0, 0)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val kind = intent.getStringExtra(EXTRA_KIND) ?: KIND_VISUAL
        val mimeTypes = if (kind == KIND_AUDIO) {
            arrayOf("audio/*")
        } else {
            arrayOf("video/*", "image/gif", "image/webp", "image/*")
        }
        openDocLauncher.launch(mimeTypes)
    }
}
