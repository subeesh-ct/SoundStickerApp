package com.soundsticker.app

import android.annotation.SuppressLint
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.PixelFormat
import android.media.MediaRecorder
import android.net.Uri
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.provider.OpenableColumns
import android.view.Gravity
import android.view.LayoutInflater
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.Button
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast
import androidx.core.app.NotificationCompat
import java.io.File
import kotlin.math.abs

class StickerForegroundService : Service() {

    companion object {
        const val ACTION_START = "com.soundsticker.app.START"
        const val ACTION_STOP = "com.soundsticker.app.STOP"
        const val ACTION_REATTACH_WEBVIEW = "com.soundsticker.app.REATTACH"
        private const val CHANNEL_ID = "sound_sticker_service"
        private const val NOTIF_ID = 1001
    }

    private lateinit var windowManager: WindowManager
    private var hiddenWebContainer: FrameLayout? = null
    private var overlayRoot: View? = null
    private var overlayParams: WindowManager.LayoutParams? = null

    private var bubbleCollapsed: View? = null
    private var popupExpanded: View? = null
    private var tvTargetChat: TextView? = null
    private var tvTargetNumber: TextView? = null
    private var btnToggleSelf: TextView? = null
    private var etManualPhone: EditText? = null
    private var tvVisualName: TextView? = null
    private var tvAudioStatus: TextView? = null
    private var btnRecordMic: Button? = null
    private var btnPickAudio: Button? = null
    private var btnUseVideoSound: Button? = null
    private var progressSend: ProgressBar? = null
    private var tvSendStatus: TextView? = null
    private var btnSendSticker: Button? = null

    private var isExpanded = false
    private var sendToSelf = false
    private var selectedVisualUri: Uri? = null
    private var selectedAudioUri: Uri? = null
    private var recordedAudioFile: File? = null
    private var audioMode = "video" // "video", "file", "mic"

    private var mediaRecorder: MediaRecorder? = null
    private var isRecording = false
    private var recordStartMs = 0L
    private val mainHandler = Handler(Looper.getMainLooper())

    private val recordTimerRunnable = object : Runnable {
        override fun run() {
            if (!isRecording) return
            val sec = ((System.currentTimeMillis() - recordStartMs) / 1000).toInt()
            btnRecordMic?.text = "Stop (${sec}s)"
            mainHandler.postDelayed(this, 500)
        }
    }

    private val stateListener: () -> Unit = {
        updateOverlayVisibility()
        updateTargetHeader()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
        WaWebEngine.init(applicationContext)
        WaWebEngine.ensureLoaded()
        AppState.addListener(stateListener)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_STOP -> {
                stopSelf()
                return START_NOT_STICKY
            }
            ACTION_REATTACH_WEBVIEW -> {
                if (!AppState.isQrScreenOpen) {
                    hiddenWebContainer?.let { WaWebEngine.attachTo(it) }
                }
                return START_STICKY
            }
        }

        startAsForeground()
        setupHiddenWebViewHost()
        setupFloatingOverlay()
        AppState.isServiceRunning = true
        AppState.notifyChange()
        return START_STICKY
    }

    private fun startAsForeground() {
        val nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
        val channel = NotificationChannel(
            CHANNEL_ID,
            "Sound Sticker Active Service",
            NotificationManager.IMPORTANCE_LOW
        )
        nm.createNotificationChannel(channel)

        val openIntent = PendingIntent.getActivity(
            this, 0,
            Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val stopIntent = PendingIntent.getService(
            this, 1,
            Intent(this, StickerForegroundService::class.java).apply { action = ACTION_STOP },
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )

        val notif: Notification = NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_sound_sticker)
            .setContentTitle("Sound Sticker Active")
            .setContentText("Side pop-up ready for WhatsApp sound stickers")
            .setOngoing(true)
            .setContentIntent(openIntent)
            .addAction(0, "Turn OFF", stopIntent)
            .build()

        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(NOTIF_ID, notif, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        } else {
            startForeground(NOTIF_ID, notif)
        }
    }

    private fun setupHiddenWebViewHost() {
        if (hiddenWebContainer != null) {
            if (!AppState.isQrScreenOpen) {
                WaWebEngine.attachTo(hiddenWebContainer!!)
            }
            return
        }
        val host = FrameLayout(this).apply { alpha = 0.01f }
        val params = WindowManager.LayoutParams(
            2, 2,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = 0
            y = 0
        }
        try {
            windowManager.addView(host, params)
            hiddenWebContainer = host
            if (!AppState.isQrScreenOpen) {
                WaWebEngine.attachTo(host)
            }
        } catch (_: Exception) {
        }
    }

    @SuppressLint("ClickableViewAccessibility", "InflateParams")
    private fun setupFloatingOverlay() {
        if (overlayRoot != null) return

        val view = LayoutInflater.from(this).inflate(R.layout.layout_floating_bubble, null)
        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.END
            x = 16
            y = 320
        }

        bubbleCollapsed = view.findViewById(R.id.bubbleCollapsed)
        popupExpanded = view.findViewById(R.id.popupExpanded)
        tvTargetChat = view.findViewById(R.id.tvTargetChat)
        tvTargetNumber = view.findViewById(R.id.tvTargetNumber)
        btnToggleSelf = view.findViewById(R.id.btnToggleSelf)
        etManualPhone = view.findViewById(R.id.etManualPhone)
        tvVisualName = view.findViewById(R.id.tvVisualName)
        tvAudioStatus = view.findViewById(R.id.tvAudioStatus)
        btnRecordMic = view.findViewById(R.id.btnRecordMic)
        btnPickAudio = view.findViewById(R.id.btnPickAudio)
        btnUseVideoSound = view.findViewById(R.id.btnUseVideoSound)
        progressSend = view.findViewById(R.id.progressSend)
        tvSendStatus = view.findViewById(R.id.tvSendStatus)
        btnSendSticker = view.findViewById(R.id.btnSendSticker)

        // Draggable collapsed bubble
        var initX = 0
        var initY = 0
        var downX = 0f
        var downY = 0f
        bubbleCollapsed?.setOnTouchListener { _, ev ->
            when (ev.action) {
                MotionEvent.ACTION_DOWN -> {
                    initX = params.x
                    initY = params.y
                    downX = ev.rawX
                    downY = ev.rawY
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    params.x = initX - (ev.rawX - downX).toInt()
                    params.y = initY + (ev.rawY - downY).toInt()
                    try { windowManager.updateViewLayout(view, params) } catch (_: Exception) {}
                    true
                }
                MotionEvent.ACTION_UP -> {
                    if (abs(ev.rawX - downX) < 12 && abs(ev.rawY - downY) < 12) {
                        setExpanded(true)
                    }
                    true
                }
                else -> false
            }
        }

        view.findViewById<View>(R.id.btnClosePopup).setOnClickListener {
            if (isRecording) stopRecording()
            setExpanded(false)
        }

        btnToggleSelf?.setOnClickListener {
            sendToSelf = !sendToSelf
            updateTargetHeader()
        }

        view.findViewById<Button>(R.id.btnPickVisual).setOnClickListener {
            MediaPickerActivity.launch(this, MediaPickerActivity.KIND_VISUAL) { uri ->
                if (uri != null) {
                    selectedVisualUri = uri
                    val name = getDisplayName(uri)
                    tvVisualName?.text = name
                    if (name.lowercase().endsWith(".gif") && audioMode == "video") {
                        tvAudioStatus?.text = "GIF selected: pick audio or record mic"
                    }
                }
            }
        }

        btnPickAudio?.setOnClickListener {
            if (isRecording) stopRecording()
            MediaPickerActivity.launch(this, MediaPickerActivity.KIND_AUDIO) { uri ->
                if (uri != null) {
                    selectedAudioUri = uri
                    audioMode = "file"
                    tvAudioStatus?.text = "Audio: " + getDisplayName(uri)
                    highlightAudioButtons()
                }
            }
        }

        btnUseVideoSound?.setOnClickListener {
            if (isRecording) stopRecording()
            audioMode = "video"
            tvAudioStatus?.text = "Using video original sound"
            highlightAudioButtons()
        }

        btnRecordMic?.setOnClickListener {
            if (isRecording) {
                stopRecording()
            } else {
                startRecording()
            }
        }

        btnSendSticker?.setOnClickListener {
            triggerSend()
        }

        try {
            windowManager.addView(view, params)
            overlayRoot = view
            overlayParams = params
            updateTargetHeader()
            updateOverlayVisibility()
        } catch (e: Exception) {
            Toast.makeText(this, "Overlay permission required", Toast.LENGTH_SHORT).show()
        }
    }

    private fun setExpanded(expand: Boolean) {
        isExpanded = expand
        bubbleCollapsed?.visibility = if (expand) View.GONE else View.VISIBLE
        popupExpanded?.visibility = if (expand) View.VISIBLE else View.GONE
        val params = overlayParams ?: return
        val root = overlayRoot ?: return
        params.flags = if (expand) {
            WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL
        } else {
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
        }
        try { windowManager.updateViewLayout(root, params) } catch (_: Exception) {}
        if (expand) updateTargetHeader()
    }

    private fun updateOverlayVisibility() {
        val root = overlayRoot ?: return
        val shouldShow = if (AppState.onlyShowInWhatsApp) {
            AppState.isInWhatsApp || isExpanded
        } else {
            true
        }
        root.visibility = if (shouldShow) View.VISIBLE else View.GONE
    }

    private fun updateTargetHeader() {
        if (sendToSelf) {
            tvTargetChat?.text = "To: Myself (Saved / Star)"
            tvTargetNumber?.text = "Sends to your own WhatsApp chat"
            btnToggleSelf?.text = "Auto"
        } else {
            val chat = AppState.detectedChatName
            val phone = AppState.detectedPhoneNumber
            tvTargetChat?.text = if (chat.isNotEmpty()) "To: $chat" else "To: Open a WhatsApp Chat"
            tvTargetNumber?.text = when {
                phone.isNotEmpty() -> "Number: $phone"
                chat.isNotEmpty() -> "Matching by Chat / Group Name"
                else -> "Or tap Self / type phone below"
            }
            btnToggleSelf?.text = "Self"
        }
    }

    private fun highlightAudioButtons() {
        val activeColor = getColor(R.color.accent_blue)
        val idleColor = 0xFF1F2937.toInt()
        btnUseVideoSound?.backgroundTintList = android.content.res.ColorStateList.valueOf(if (audioMode == "video") activeColor else idleColor)
        btnPickAudio?.backgroundTintList = android.content.res.ColorStateList.valueOf(if (audioMode == "file") activeColor else idleColor)
        btnRecordMic?.backgroundTintList = android.content.res.ColorStateList.valueOf(if (audioMode == "mic") activeColor else idleColor)
    }

    @Suppress("DEPRECATION")
    private fun startRecording() {
        try {
            val outFile = File(cacheDir, "voice_sticker.m4a")
            if (outFile.exists()) outFile.delete()
            val mr = if (Build.VERSION.SDK_INT >= 31) MediaRecorder(this) else MediaRecorder()
            mr.setAudioSource(MediaRecorder.AudioSource.MIC)
            mr.setOutputFormat(MediaRecorder.OutputFormat.MPEG_4)
            mr.setAudioEncoder(MediaRecorder.AudioEncoder.AAC)
            mr.setAudioSamplingRate(44100)
            mr.setAudioEncodingBitRate(96000)
            mr.setOutputFile(outFile.absolutePath)
            mr.prepare()
            mr.start()

            mediaRecorder = mr
            recordedAudioFile = outFile
            isRecording = true
            recordStartMs = System.currentTimeMillis()
            audioMode = "mic"
            btnRecordMic?.text = "Stop (0s)"
            tvAudioStatus?.text = "Recording voice..."
            highlightAudioButtons()
            mainHandler.postDelayed(recordTimerRunnable, 500)
        } catch (e: Exception) {
            Toast.makeText(this, "Mic error: grant Microphone permission", Toast.LENGTH_SHORT).show()
        }
    }

    private fun stopRecording() {
        isRecording = false
        mainHandler.removeCallbacks(recordTimerRunnable)
        try {
            mediaRecorder?.stop()
            mediaRecorder?.release()
        } catch (_: Exception) {
        }
        mediaRecorder = null
        val sec = ((System.currentTimeMillis() - recordStartMs) / 1000).coerceAtLeast(1)
        btnRecordMic?.text = "Record Mic"
        tvAudioStatus?.text = "Recorded voice ready (${sec}s)"
        highlightAudioButtons()
    }

    private fun triggerSend() {
        if (isRecording) stopRecording()
        val visualUri = selectedVisualUri
        if (visualUri == null) {
            Toast.makeText(this, "First pick a Video or GIF", Toast.LENGTH_SHORT).show()
            return
        }
        if (!AppState.isWhatsAppConnected) {
            Toast.makeText(this, "Link WhatsApp first inside the app", Toast.LENGTH_LONG).show()
            return
        }

        val manual = etManualPhone?.text?.toString()?.trim().orEmpty()
        val targetPhone = when {
            sendToSelf -> "__SELF__"
            manual.isNotEmpty() -> manual
            else -> AppState.detectedPhoneNumber
        }
        val targetName = if (sendToSelf || manual.isNotEmpty()) "" else AppState.detectedChatName

        btnSendSticker?.isEnabled = false
        progressSend?.visibility = View.VISIBLE
        progressSend?.progress = 5
        tvSendStatus?.visibility = View.VISIBLE
        tvSendStatus?.text = "Starting..."

        WaWebEngine.sendSoundSticker(
            context = this,
            visualUri = visualUri,
            audioUri = if (audioMode == "file") selectedAudioUri else null,
            recordedAudioFile = if (audioMode == "mic") recordedAudioFile else null,
            useVideoAudio = (audioMode == "video"),
            phone = targetPhone,
            chatName = targetName,
            callback = object : WaWebEngine.SendCallback {
                override fun onProgress(message: String, percent: Int) {
                    progressSend?.progress = percent
                    tvSendStatus?.text = message
                }

                override fun onComplete(success: Boolean, message: String) {
                    btnSendSticker?.isEnabled = true
                    tvSendStatus?.text = if (success) "Done: $message" else "Error: $message"
                    Toast.makeText(this@StickerForegroundService, message, Toast.LENGTH_SHORT).show()
                    if (success) {
                        mainHandler.postDelayed({
                            progressSend?.visibility = View.GONE
                            setExpanded(false)
                        }, 1200)
                    }
                }
            }
        )
    }

    private fun getDisplayName(uri: Uri): String {
        return try {
            contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c ->
                if (c.moveToFirst()) c.getString(0) else "Selected"
            } ?: "Selected"
        } catch (_: Exception) {
            "Selected"
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        if (isRecording) stopRecording()
        AppState.removeListener(stateListener)
        AppState.isServiceRunning = false
        AppState.notifyChange()
        hiddenWebContainer?.let {
            WaWebEngine.detachIfAttachedTo(it)
            try { windowManager.removeView(it) } catch (_: Exception) {}
        }
        overlayRoot?.let {
            try { windowManager.removeView(it) } catch (_: Exception) {}
        }
    }
}
