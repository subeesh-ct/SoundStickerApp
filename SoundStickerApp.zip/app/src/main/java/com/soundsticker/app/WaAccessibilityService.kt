package com.soundsticker.app

import android.Manifest
import android.accessibilityservice.AccessibilityService
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.SystemClock
import android.provider.ContactsContract
import android.provider.Settings
import android.view.accessibility.AccessibilityEvent
import androidx.core.content.ContextCompat

class WaAccessibilityService : AccessibilityService() {

    private var lastLookedUpName: String = ""
    private var lastResolvedPhone: String = ""
    private var lastWakeMs: Long = 0L

    override fun onServiceConnected() {
        super.onServiceConnected()
        checkActiveWindowNow()
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event == null) return
        val pkg = event.packageName?.toString() ?: return

        // Ignore our own overlay, system UI, and keyboards so typing/popups don't hide the bubble
        if (isIgnoredPackage(pkg)) return

        val isWaEvent = (pkg == "com.whatsapp" || pkg == "com.whatsapp.w4b")
        val rootPkg = try { rootInActiveWindow?.packageName?.toString() } catch (_: Exception) { null }
        val isWaRoot = (rootPkg == "com.whatsapp" || rootPkg == "com.whatsapp.w4b")

        if (isWaEvent || isWaRoot) {
            if (!AppState.isInWhatsApp) {
                AppState.isInWhatsApp = true
                AppState.notifyChange()
            }
            ensureForegroundServiceAlive()
            detectChatTitle(if (isWaEvent) pkg else (rootPkg ?: "com.whatsapp"))
        } else if (event.eventType == AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) {
            // Only mark as left WhatsApp on an actual window switch to another real app
            if (AppState.isInWhatsApp) {
                AppState.isInWhatsApp = false
                AppState.notifyChange()
            }
        }
    }

    private fun checkActiveWindowNow() {
        try {
            val rootPkg = rootInActiveWindow?.packageName?.toString() ?: return
            val isWa = (rootPkg == "com.whatsapp" || rootPkg == "com.whatsapp.w4b")
            if (AppState.isInWhatsApp != isWa) {
                AppState.isInWhatsApp = isWa
                AppState.notifyChange()
            }
            if (isWa) {
                ensureForegroundServiceAlive()
                detectChatTitle(rootPkg)
            }
        } catch (_: Exception) {
        }
    }

    private fun isIgnoredPackage(pkg: String): Boolean {
        if (pkg == packageName || pkg == "com.android.systemui" || pkg == "android") return true
        val lower = pkg.lowercase()
        return lower.contains("inputmethod") ||
            lower.contains("keyboard") ||
            lower.contains("gboard") ||
            lower.contains("swiftkey") ||
            lower.contains("ime")
    }

    private fun ensureForegroundServiceAlive() {
        if (AppState.isServiceRunning) return
        val now = SystemClock.elapsedRealtime()
        if (now - lastWakeMs < 5000L) return

        val prefs = getSharedPreferences(StickerForegroundService.PREFS_NAME, Context.MODE_PRIVATE)
        val userWantsService = prefs.getBoolean(StickerForegroundService.KEY_USER_WANTS_SERVICE, false)
        if (!userWantsService) return
        if (!Settings.canDrawOverlays(this)) return

        lastWakeMs = now
        try {
            val intent = Intent(this, StickerForegroundService::class.java).apply {
                action = StickerForegroundService.ACTION_START
            }
            ContextCompat.startForegroundService(this, intent)
        } catch (_: Exception) {
        }
    }

    private fun detectChatTitle(pkg: String) {
        try {
            val root = rootInActiveWindow ?: return
            val idCandidates = listOf(
                "$pkg:id/conversation_contact_name",
                "$pkg:id/newsletter_name",
                "$pkg:id/channel_name",
                "$pkg:id/toolbar_title",
                "com.whatsapp:id/conversation_contact_name",
                "com.whatsapp.w4b:id/conversation_contact_name"
            )
            var foundTitle: String? = null
            for (viewId in idCandidates) {
                val nodes = root.findAccessibilityNodeInfosByViewId(viewId)
                if (!nodes.isNullOrEmpty()) {
                    val txt = nodes[0].text?.toString()?.trim()
                    if (!txt.isNullOrEmpty()) {
                        foundTitle = cleanTitle(txt)
                        break
                    }
                }
            }

            if (!foundTitle.isNullOrEmpty() && foundTitle != AppState.detectedChatName) {
                AppState.detectedChatName = foundTitle
                AppState.detectedPhoneNumber = if (isSelfChatTitle(foundTitle)) {
                    "__SELF__"
                } else {
                    resolvePhoneNumber(foundTitle)
                }
                AppState.notifyChange()
            }
        } catch (_: Exception) {
        }
    }

    private fun cleanTitle(raw: String): String {
        return raw.replace(Regex("[\\u200E\\u200F\\u202A-\\u202E\\u2066-\\u2069]"), "").trim()
    }

    private fun isSelfChatTitle(title: String): Boolean {
        val lower = title.lowercase()
        return lower == "you" ||
            lower.endsWith("(you)") ||
            lower == "நீங்கள்" ||
            lower.endsWith("(நீங்கள்)")
    }

    private fun resolvePhoneNumber(chatTitle: String): String {
        val digitsOnly = chatTitle.filter { it.isDigit() }
        if (digitsOnly.length >= 10 && chatTitle.all { it.isDigit() || it in "+-() " }) {
            return digitsOnly
        }

        if (chatTitle == lastLookedUpName) return lastResolvedPhone
        lastLookedUpName = chatTitle
        lastResolvedPhone = ""

        if (ContextCompat.checkSelfPermission(this, Manifest.permission.READ_CONTACTS)
            != PackageManager.PERMISSION_GRANTED
        ) {
            return ""
        }

        try {
            val projection = arrayOf(ContactsContract.CommonDataKinds.Phone.NUMBER)
            val selection = "LOWER(${ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME}) = LOWER(?)"
            contentResolver.query(
                ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
                projection,
                selection,
                arrayOf(chatTitle),
                null
            )?.use { cursor ->
                if (cursor.moveToFirst()) {
                    val raw = cursor.getString(0) ?: ""
                    lastResolvedPhone = raw.filter { it.isDigit() }
                }
            }
        } catch (_: Exception) {
        }
        return lastResolvedPhone
    }

    override fun onInterrupt() {}
}