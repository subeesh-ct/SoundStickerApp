package com.soundsticker.app

import android.Manifest
import android.accessibilityservice.AccessibilityService
import android.content.pm.PackageManager
import android.provider.ContactsContract
import android.view.accessibility.AccessibilityEvent
import androidx.core.content.ContextCompat

class WaAccessibilityService : AccessibilityService() {

    private var lastLookedUpName: String = ""
    private var lastResolvedPhone: String = ""

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event == null) return
        val pkg = event.packageName?.toString() ?: return

        // Ignore our own overlay and system UI so tapping the pop-up doesn't clear the detected chat
        if (pkg == packageName || pkg == "com.android.systemui") return

        val isWa = (pkg == "com.whatsapp" || pkg == "com.whatsapp.w4b")
        if (AppState.isInWhatsApp != isWa) {
            AppState.isInWhatsApp = isWa
            AppState.notifyChange()
        }

        if (!isWa) return

        try {
            val root = rootInActiveWindow ?: return
            val idCandidates = listOf(
                "$pkg:id/conversation_contact_name",
                "com.whatsapp:id/conversation_contact_name",
                "com.whatsapp.w4b:id/conversation_contact_name"
            )
            var foundTitle: String? = null
            for (viewId in idCandidates) {
                val nodes = root.findAccessibilityNodeInfosByViewId(viewId)
                if (!nodes.isNullOrEmpty()) {
                    val txt = nodes[0].text?.toString()?.trim()
                    if (!txt.isNullOrEmpty()) {
                        foundTitle = txt
                        break
                    }
                }
            }

            if (!foundTitle.isNullOrEmpty() && foundTitle != AppState.detectedChatName) {
                AppState.detectedChatName = foundTitle
                AppState.detectedPhoneNumber = resolvePhoneNumber(foundTitle)
                AppState.notifyChange()
            }
        } catch (_: Exception) {
        }
    }

    private fun resolvePhoneNumber(chatTitle: String): String {
        // 1. If the chat title itself is an unsaved phone number (e.g. +91 98765 43210)
        val digitsOnly = chatTitle.filter { it.isDigit() }
        if (digitsOnly.length >= 10 && chatTitle.all { it.isDigit() || it in "+-() " }) {
            return digitsOnly
        }

        if (chatTitle == lastLookedUpName) return lastResolvedPhone
        lastLookedUpName = chatTitle
        lastResolvedPhone = ""

        if (ContextCompat.checkSelfPermission(this, Manifest.permission.READ_CONTACTS)
            != PackageManager.PERMISSION_GRANTED
        ) {
            return ""
        }

        try {
            val projection = arrayOf(ContactsContract.CommonDataKinds.Phone.NUMBER)
            val selection = "${ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME} = ?"
            contentResolver.query(
                ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
                projection,
                selection,
                arrayOf(chatTitle),
                null
            )?.use { cursor ->
                if (cursor.moveToFirst()) {
                    val raw = cursor.getString(0) ?: ""
                    lastResolvedPhone = raw.filter { it.isDigit() }
                }
            }
        } catch (_: Exception) {
        }
        return lastResolvedPhone
    }

    override fun onInterrupt() {}
}
