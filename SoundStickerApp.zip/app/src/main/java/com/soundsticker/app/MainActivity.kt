
package com.soundsticker.app

import android.Manifest
import android.app.ActivityManager
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.View
import android.widget.Button
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.PopupMenu
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.SwitchCompat
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat

class MainActivity : AppCompatActivity() {

    private lateinit var tvWaBadge: TextView
    private lateinit var btnMoreMenu: TextView
    private lateinit var btnPower: LinearLayout
    private lateinit var tvPowerLabel: TextView
    private lateinit var tvPowerStatus: TextView
    private lateinit var btnPermOverlay: LinearLayout
    private lateinit var tvStatusOverlay: TextView
    private lateinit var btnPermAccessibility: LinearLayout
    private lateinit var tvStatusAccessibility: TextView
    private lateinit var btnPermRuntime: LinearLayout
    private lateinit var tvStatusRuntime: TextView
    private lateinit var switchOnlyWa: SwitchCompat
    private lateinit var qrOverlayLayout: LinearLayout
    private lateinit var qrWebContainer: FrameLayout

    private val stateListener: () -> Unit = {
        runOnUiThread { refreshUi() }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val prefs = getSharedPreferences("sound_sticker_prefs", MODE_PRIVATE)
        AppState.onlyShowInWhatsApp = prefs.getBoolean("only_show_in_wa", false)

        WaWebEngine.init(applicationContext)

        tvWaBadge = findViewById(R.id.tvWaBadge)
        btnMoreMenu = findViewById(R.id.btnMoreMenu)
        btnPower = findViewById(R.id.btnPower)
        tvPowerLabel = findViewById(R.id.tvPowerLabel)
        tvPowerStatus = findViewById(R.id.tvPowerStatus)
        btnPermOverlay = findViewById(R.id.btnPermOverlay)
        tvStatusOverlay = findViewById(R.id.tvStatusOverlay)
        btnPermAccessibility = findViewById(R.id.btnPermAccessibility)
        tvStatusAccessibility = findViewById(R.id.tvStatusAccessibility)
        btnPermRuntime = findViewById(R.id.btnPermRuntime)
        tvStatusRuntime = findViewById(R.id.tvStatusRuntime)
        switchOnlyWa = findViewById(R.id.switchOnlyWa)
        qrOverlayLayout = findViewById(R.id.qrOverlayLayout)
        qrWebContainer = findViewById(R.id.qrWebContainer)

        btnMoreMenu.setOnClickListener { anchor ->
            showMoreMenu(anchor)
        }

        btnPower.setOnClickListener {
            if (AppState.isServiceRunning || isStickerServiceRunning()) {
                val stopIntent = Intent(this, StickerForegroundService::class.java).apply {
                    action = StickerForegroundService.ACTION_STOP
                }
                startService(stopIntent)
                AppState.isServiceRunning = false
                refreshUi()
            } else {
                val missingPerms = getMissingPermissions()
                if (missingPerms.isNotEmpty()) {
                    showMissingPermissionsDialog(missingPerms)
                    return@setOnClickListener
                }
                val startIntent = Intent(this, StickerForegroundService::class.java).apply {
                    action = StickerForegroundService.ACTION_START
                }
                startForegroundService(startIntent)
            }
        }

        findViewById<Button>(R.id.btnLinkWa).setOnClickListener {
            openQrScreen()
        }

        findViewById<Button>(R.id.btnQrReload).setOnClickListener {
            WaWebEngine.manualReload()
        }

        findViewById<Button>(R.id.btnQrClose).setOnClickListener {
            closeQrScreen()
        }

        btnPermOverlay.setOnClickListener { openOverlaySettings() }

        btnPermAccessibility.setOnClickListener {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        }

        btnPermRuntime.setOnClickListener {
            requestRuntimePermissions()
        }

        switchOnlyWa.isChecked = AppState.onlyShowInWhatsApp
        switchOnlyWa.setOnCheckedChangeListener { _, isChecked ->
            AppState.onlyShowInWhatsApp = isChecked
            prefs.edit().putBoolean("only_show_in_wa", isChecked).apply()
            AppState.notifyChange()
        }

        AppState.addListener(stateListener)
        syncServiceState()

        // Auto-verify WhatsApp connection immediately on app open
        if (!AppState.isServiceRunning) {
            WaWebEngine.attachTo(qrWebContainer)
        }
        WaWebEngine.ensureLoaded()

        refreshUi()

        if (savedInstanceState == null) {
            showStartupNoticeDialog()
        }
    }

    private fun showStartupNoticeDialog() {
        AlertDialog.Builder(this)
            .setTitle("Before You Start")
            .setMessage(
                "1. Update WhatsApp:\n" +
                    "Please update your WhatsApp app to the latest version on the Play Store before trying this app.\n\n" +
                    "2. Permissions & Open Source:\n" +
                    "Allow all required permissions properly. This app is 100% Open Source and runs locally on your device—you can check the full code on GitHub.\n\n" +
                    "3. Sending Tip:\n" +
                    "If you get any error while creating or sending a sticker, try sending it to another chat instead of your own chat."
            )
            .setPositiveButton("OK", null)
            .show()
    }

    @Suppress("DEPRECATION")
    private fun isStickerServiceRunning(): Boolean {
        return try {
            val am = getSystemService(ACTIVITY_SERVICE) as ActivityManager
            am.getRunningServices(Int.MAX_VALUE).any {
                it.service.className == StickerForegroundService::class.java.name
            }
        } catch (_: Exception) {
            AppState.isServiceRunning
        }
    }

    private fun syncServiceState() {
        AppState.isServiceRunning = isStickerServiceRunning()
    }

    private fun getMissingPermissions(): List<String> {
        val missing = mutableListOf<String>()
        if (!Settings.canDrawOverlays(this)) {
            missing.add("• Floating Pop-up Permission")
        }
        if (!isAccessibilityEnabled()) {
            missing.add("• Auto-Detect Chat (Accessibility)")
        }
        if (!areRuntimePermissionsGranted()) {
            missing.add("• Mic, Contacts & Notification")
        }
        return missing
    }

    private fun showMissingPermissionsDialog(missingPerms: List<String>) {
        val listText = missingPerms.joinToString("\n")
        AlertDialog.Builder(this)
            .setTitle("Permissions Required")
            .setMessage(
                "Please enable all required permissions first, then try again:\n\n$listText"
            )
            .setPositiveButton("OK", null)
            .show()
    }

    private fun showMoreMenu(anchor: View) {
        val popup = PopupMenu(this, anchor)
        popup.menu.add(0, 1, 0, "YouTube")
        popup.menu.add(0, 2, 1, "Join Our Community")
        popup.menu.add(0, 3, 2, "Developer Info")
        popup.menu.add(0, 4, 3, "Important Info")
        popup.setOnMenuItemClickListener { item ->
            if (item.itemId == 4) {
                showStartupNoticeDialog()
                return@setOnMenuItemClickListener true
            }
            val targetUrl = when (item.itemId) {
                1 -> "https://youtube.com/@codingtheriyuma"
                2 -> "tg:resolve?domain=SubeeshZero"
                3 -> "https://subeesh-zero.github.io/Profile/"
                else -> null
            }
            if (targetUrl != null) {
                openExternalLink(targetUrl)
                true
            } else {
                false
            }
        }
        popup.show()
    }

    private fun openExternalLink(url: String) {
        try {
            val intent = Intent(Intent.ACTION_VIEW, Uri.parse(url)).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            startActivity(intent)
        } catch (_: Exception) {
            Toast.makeText(this, "Cannot open link", Toast.LENGTH_SHORT).show()
        }
    }

    private fun openQrScreen() {
        AppState.isQrScreenOpen = true
        qrOverlayLayout.visibility = View.VISIBLE
        WaWebEngine.attachTo(qrWebContainer)
        WaWebEngine.ensureLoaded()
    }

    private fun closeQrScreen() {
        AppState.isQrScreenOpen = false
        qrOverlayLayout.visibility = View.GONE
        if (AppState.isServiceRunning) {
            WaWebEngine.detachIfAttachedTo(qrWebContainer)
            val intent = Intent(this, StickerForegroundService::class.java).apply {
                action = StickerForegroundService.ACTION_REATTACH_WEBVIEW
            }
            startService(intent)
        }
    }

    private fun openOverlaySettings() {
        val intent = Intent(
            Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
            Uri.parse("package:$packageName")
        )
        startActivity(intent)
    }

    private fun requiredRuntimePermissions(): List<String> {
        val perms = mutableListOf(
            Manifest.permission.RECORD_AUDIO,
            Manifest.permission.READ_CONTACTS
        )
        if (Build.VERSION.SDK_INT >= 33) {
            perms.add(Manifest.permission.POST_NOTIFICATIONS)
            perms.add(Manifest.permission.READ_MEDIA_VIDEO)
            perms.add(Manifest.permission.READ_MEDIA_AUDIO)
            perms.add(Manifest.permission.READ_MEDIA_IMAGES)
        } else {
            perms.add(Manifest.permission.READ_EXTERNAL_STORAGE)
        }
        return perms
    }

    private fun areRuntimePermissionsGranted(): Boolean {
        return requiredRuntimePermissions().all {
            ContextCompat.checkSelfPermission(this, it) == PackageManager.PERMISSION_GRANTED
        }
    }

    private fun requestRuntimePermissions() {
        val missing = requiredRuntimePermissions().filter {
            ContextCompat.checkSelfPermission(this, it) != PackageManager.PERMISSION_GRANTED
        }
        if (missing.isEmpty()) {
            Toast.makeText(this, "All runtime permissions granted!", Toast.LENGTH_SHORT).show()
        } else {
            ActivityCompat.requestPermissions(this, missing.toTypedArray(), 200)
        }
    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == 200) {
            refreshUi()
        }
    }

    private fun isAccessibilityEnabled(): Boolean {
        val enabled = Settings.Secure.getString(
            contentResolver,
            Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES
        ) ?: return false
        return enabled.contains("$packageName/.WaAccessibilityService") ||
            enabled.contains("$packageName/${WaAccessibilityService::class.java.name}")
    }

    private fun setIndicator(tv: TextView, granted: Boolean) {
        if (granted) {
            tv.text = "✓ ON"
            tv.setTextColor(getColor(R.color.status_green))
        } else {
            tv.text = "✗ OFF"
            tv.setTextColor(getColor(R.color.status_red))
        }
    }

    private fun refreshUi() {
        if (AppState.isWhatsAppConnected) {
            tvWaBadge.text = "WA: Connected"
            tvWaBadge.setTextColor(getColor(R.color.status_green))
        } else {
            tvWaBadge.text = "WA: Not Linked"
            tvWaBadge.setTextColor(getColor(R.color.status_red))
        }

        if (AppState.isServiceRunning) {
            btnPower.setBackgroundResource(R.drawable.bg_power_on)
            tvPowerLabel.text = "TURN OFF"
            tvPowerStatus.text = "Active - Floating side button is ON"
            tvPowerStatus.setTextColor(getColor(R.color.status_green))
        } else {
            btnPower.setBackgroundResource(R.drawable.bg_power_off)
            tvPowerLabel.text = "TURN ON"
            tvPowerStatus.text = "Service is OFF"
            tvPowerStatus.setTextColor(getColor(R.color.text_secondary))
        }

        setIndicator(tvStatusOverlay, Settings.canDrawOverlays(this))
        setIndicator(tvStatusAccessibility, isAccessibilityEnabled())
        setIndicator(tvStatusRuntime, areRuntimePermissionsGranted())
    }

    override fun onResume() {
        super.onResume()
        syncServiceState()
        WaWebEngine.checkConnectionNow()
        refreshUi()
        if (AppState.isQrScreenOpen) {
            WaWebEngine.attachTo(qrWebContainer)
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        AppState.removeListener(stateListener)
        if (AppState.isQrScreenOpen) {
            AppState.isQrScreenOpen = false
            WaWebEngine.detachIfAttachedTo(qrWebContainer)
            if (AppState.isServiceRunning) {
                val intent = Intent(this, StickerForegroundService::class.java).apply {
                    action = StickerForegroundService.ACTION_REATTACH_WEBVIEW
                }
                startService(intent)
            }
        }
    }
}
