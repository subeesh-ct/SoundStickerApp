package com.soundsticker.app

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.View
import android.widget.Button
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.SwitchCompat
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat

class MainActivity : AppCompatActivity() {

    private lateinit var tvWaBadge: TextView
    private lateinit var btnPower: LinearLayout
    private lateinit var tvPowerLabel: TextView
    private lateinit var tvPowerStatus: TextView
    private lateinit var btnPermOverlay: Button
    private lateinit var btnPermAccessibility: Button
    private lateinit var switchOnlyWa: SwitchCompat
    private lateinit var qrOverlayLayout: LinearLayout
    private lateinit var qrWebContainer: FrameLayout

    private val stateListener: () -> Unit = {
        refreshUi()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        WaWebEngine.init(applicationContext)

        tvWaBadge = findViewById(R.id.tvWaBadge)
        btnPower = findViewById(R.id.btnPower)
        tvPowerLabel = findViewById(R.id.tvPowerLabel)
        tvPowerStatus = findViewById(R.id.tvPowerStatus)
        btnPermOverlay = findViewById(R.id.btnPermOverlay)
        btnPermAccessibility = findViewById(R.id.btnPermAccessibility)
        switchOnlyWa = findViewById(R.id.switchOnlyWa)
        qrOverlayLayout = findViewById(R.id.qrOverlayLayout)
        qrWebContainer = findViewById(R.id.qrWebContainer)

        btnPower.setOnClickListener {
            if (AppState.isServiceRunning) {
                val stopIntent = Intent(this, StickerForegroundService::class.java).apply {
                    action = StickerForegroundService.ACTION_STOP
                }
                startService(stopIntent)
            } else {
                if (!Settings.canDrawOverlays(this)) {
                    Toast.makeText(this, "Grant Floating Pop-up Permission first", Toast.LENGTH_SHORT).show()
                    openOverlaySettings()
                    return@setOnClickListener
                }
                val startIntent = Intent(this, StickerForegroundService::class.java).apply {
                    action = StickerForegroundService.ACTION_START
                }
                startForegroundService(startIntent)
            }
        }

        findViewById<Button>(R.id.btnLinkWa).setOnClickListener {
            openQrScreen()
        }

        findViewById<Button>(R.id.btnQrReload).setOnClickListener {
            WaWebEngine.manualReload()
        }

        findViewById<Button>(R.id.btnQrClose).setOnClickListener {
            closeQrScreen()
        }

        btnPermOverlay.setOnClickListener { openOverlaySettings() }

        btnPermAccessibility.setOnClickListener {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        }

        findViewById<Button>(R.id.btnPermRuntime).setOnClickListener {
            requestRuntimePermissions()
        }

        switchOnlyWa.setOnCheckedChangeListener { _, isChecked ->
            AppState.onlyShowInWhatsApp = isChecked
            AppState.notifyChange()
        }

        AppState.addListener(stateListener)
        refreshUi()
    }

    private fun openQrScreen() {
        AppState.isQrScreenOpen = true
        qrOverlayLayout.visibility = View.VISIBLE
        WaWebEngine.attachTo(qrWebContainer)
        WaWebEngine.ensureLoaded()
    }

    private fun closeQrScreen() {
        AppState.isQrScreenOpen = false
        qrOverlayLayout.visibility = View.GONE
        WaWebEngine.detachIfAttachedTo(qrWebContainer)
        if (AppState.isServiceRunning) {
            val intent = Intent(this, StickerForegroundService::class.java).apply {
                action = StickerForegroundService.ACTION_REATTACH_WEBVIEW
            }
            startService(intent)
        }
    }

    private fun openOverlaySettings() {
        val intent = Intent(
            Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
            Uri.parse("package:$packageName")
        )
        startActivity(intent)
    }

    private fun requestRuntimePermissions() {
        val perms = mutableListOf(
            Manifest.permission.RECORD_AUDIO,
            Manifest.permission.READ_CONTACTS
        )
        if (Build.VERSION.SDK_INT >= 33) {
            perms.add(Manifest.permission.POST_NOTIFICATIONS)
            perms.add(Manifest.permission.READ_MEDIA_VIDEO)
            perms.add(Manifest.permission.READ_MEDIA_AUDIO)
            perms.add(Manifest.permission.READ_MEDIA_IMAGES)
        } else {
            perms.add(Manifest.permission.READ_EXTERNAL_STORAGE)
        }
        val missing = perms.filter {
            ContextCompat.checkSelfPermission(this, it) != PackageManager.PERMISSION_GRANTED
        }
        if (missing.isEmpty()) {
            Toast.makeText(this, "All runtime permissions granted!", Toast.LENGTH_SHORT).show()
        } else {
            ActivityCompat.requestPermissions(this, missing.toTypedArray(), 200)
        }
    }

    private fun isAccessibilityEnabled(): Boolean {
        val enabled = Settings.Secure.getString(
            contentResolver,
            Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES
        ) ?: return false
        return enabled.contains("$packageName/.WaAccessibilityService") ||
            enabled.contains("$packageName/${WaAccessibilityService::class.java.name}")
    }

    private fun refreshUi() {
        if (AppState.isWhatsAppConnected) {
            tvWaBadge.text = "WA: Connected"
            tvWaBadge.setTextColor(getColor(R.color.status_green))
        } else {
            tvWaBadge.text = "WA: Not Linked"
            tvWaBadge.setTextColor(getColor(R.color.status_red))
        }

        if (AppState.isServiceRunning) {
            btnPower.setBackgroundResource(R.drawable.bg_power_on)
            tvPowerLabel.text = "TURN OFF"
            tvPowerStatus.text = "Active - Floating side button is ON"
            tvPowerStatus.setTextColor(getColor(R.color.status_green))
        } else {
            btnPower.setBackgroundResource(R.drawable.bg_power_off)
            tvPowerLabel.text = "TURN ON"
            tvPowerStatus.text = "Service is OFF"
            tvPowerStatus.setTextColor(getColor(R.color.text_secondary))
        }

        btnPermOverlay.text = if (Settings.canDrawOverlays(this)) {
            "2. Floating Pop-up Permission (OK)"
        } else {
            "2. Floating Pop-up Permission (Required)"
        }

        btnPermAccessibility.text = if (isAccessibilityEnabled()) {
            "3. Auto-Detect Chat Accessibility (OK)"
        } else {
            "3. Auto-Detect Chat Accessibility (Enable)"
        }
    }

    override fun onResume() {
        super.onResume()
        refreshUi()
        if (AppState.isQrScreenOpen) {
            WaWebEngine.attachTo(qrWebContainer)
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        AppState.removeListener(stateListener)
        if (AppState.isQrScreenOpen) {
            AppState.isQrScreenOpen = false
            WaWebEngine.detachIfAttachedTo(qrWebContainer)
            if (AppState.isServiceRunning) {
                val intent = Intent(this, StickerForegroundService::class.java).apply {
                    action = StickerForegroundService.ACTION_REATTACH_WEBVIEW
                }
                startService(intent)
            }
        }
    }
}
